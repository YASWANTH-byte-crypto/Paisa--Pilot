// PaisaPilot root script forwarder
import './public/js/app.js';
