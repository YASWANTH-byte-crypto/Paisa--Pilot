/**
 * PaisaPilot Application Controller & UI Orchestrator
 * Integrates 3-Tier Express Backend, IndexedDB, Charts, and Stretch Features.
 */

import { stateManager } from './state.js';
import { apiClient } from './api.js';
import { offlineStorage } from './db.js';
import { renderCategoryChart, renderTrendChart } from './charts.js';
import { renderBudgetMonitor } from './budgetMonitor.js';
import { computeBurnRateMetrics, updateBurnRateUI } from './burnRateEstimator.js';
import { setupSplitCalculator } from './splitCalculator.js';
import { setupReceiptScanner } from './ocrScanner.js';
import { renderSavingsBadges } from './gamification.js';
import { exportTransactionsToCSV } from './csvExport.js';

// Global toast notification helper
export function showToast(message, type = 'info') {
  const container = document.getElementById('toastContainer');
  if (!container) return;

  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  toast.innerHTML = `
    <span>${type === 'danger' ? '⚠️' : type === 'warning' ? '🔔' : '✅'}</span>
    <p>${message}</p>
  `;
  container.appendChild(toast);

  setTimeout(() => {
    toast.classList.add('toast-fadeout');
    setTimeout(() => toast.remove(), 400);
  }, 4000);
}

// Update Metric Cards
function updateMetricCards(state) {
  const allowance = state.profile.monthly_allowance_rupees || 5000;

  const totalIncome = state.transactions
    .filter(t => t.type === 'Income')
    .reduce((sum, t) => sum + (t.amount_paise ? t.amount_paise / 100 : Number(t.amount || 0)), 0);

  const totalExpenses = state.transactions
    .filter(t => t.type === 'Expense')
    .reduce((sum, t) => sum + (t.amount_paise ? t.amount_paise / 100 : Number(t.amount || 0)), 0);

  const availableBalance = allowance + totalIncome - totalExpenses;

  // Days remaining in month for safe daily spend
  const now = new Date();
  const totalDays = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate();
  const daysRemaining = Math.max(1, totalDays - now.getDate());
  const dailySafeSpend = availableBalance > 0 ? Math.floor(availableBalance / daysRemaining) : 0;

  document.getElementById('displayAllowance').textContent = `₹${allowance.toLocaleString('en-IN', { minimumFractionDigits: 2 })}`;
  document.getElementById('displayIncome').textContent = `₹${totalIncome.toLocaleString('en-IN', { minimumFractionDigits: 2 })}`;
  document.getElementById('displayExpenses').textContent = `₹${totalExpenses.toLocaleString('en-IN', { minimumFractionDigits: 2 })}`;
  
  const balanceEl = document.getElementById('displayBalance');
  balanceEl.textContent = `₹${availableBalance.toLocaleString('en-IN', { minimumFractionDigits: 2 })}`;
  balanceEl.style.color = availableBalance < 0 ? '#e74c3c' : '#168c88';

  const safeSpendEl = document.getElementById('displaySafeSpend');
  if (safeSpendEl) {
    safeSpendEl.textContent = `₹${dailySafeSpend.toLocaleString('en-IN', { minimumFractionDigits: 2 })} / day`;
  }

  // Hero previews
  const heroBal = document.getElementById('heroBalance');
  if (heroBal) heroBal.textContent = `₹${availableBalance.toLocaleString('en-IN', { minimumFractionDigits: 2 })}`;
}

// Render Transaction Ledger Table with Multi-Filter
function renderTransactionsTable(state) {
  const tbody = document.getElementById('transactionList');
  if (!tbody) return;

  const { search, category, type, startDate, endDate, sort, order } = state.activeFilters;

  let filtered = state.transactions.filter(t => {
    const matchSearch = !search || t.merchant.toLowerCase().includes(search.toLowerCase());
    const matchCategory = category === 'All' || (t.category_id || t.category || '').toLowerCase() === category.toLowerCase();
    const matchType = type === 'All' || t.type === type;
    const matchStart = !startDate || t.date >= startDate;
    const matchEnd = !endDate || t.date <= endDate;
    return matchSearch && matchCategory && matchType && matchStart && matchEnd;
  });

  // Sorting
  filtered.sort((a, b) => {
    let valA = a[sort] || '';
    let valB = b[sort] || '';
    if (sort === 'amount') {
      valA = a.amount_paise || (a.amount * 100);
      valB = b.amount_paise || (b.amount * 100);
    }
    if (order === 'ASC') return valA > valB ? 1 : -1;
    return valA < valB ? 1 : -1;
  });

  tbody.innerHTML = '';

  if (filtered.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="7" class="empty-state">
          No transactions match your search or filter criteria.
        </td>
      </tr>`;
    return;
  }

  filtered.forEach(t => {
    const tr = document.createElement('tr');
    const amountNum = t.amount_paise ? (t.amount_paise / 100) : Number(t.amount || 0);
    const isIncome = t.type === 'Income';

    tr.innerHTML = `
      <td><strong>${t.merchant}</strong>${t.notes ? `<br><small class="subtext">${t.notes}</small>` : ''}</td>
      <td><span class="category-tag">${t.category_name || t.category_id || t.category || 'Other'}</span></td>
      <td>${t.date}</td>
      <td>${t.payment_method || t.payment || 'UPI'}</td>
      <td><span class="type-badge ${isIncome ? 'type-income' : 'type-expense'}">${t.type}</span></td>
      <td class="${isIncome ? 'amount-income' : 'amount-expense'}">
        ${isIncome ? '+ ₹' : '- ₹'}${amountNum.toFixed(2)}
      </td>
      <td>
        <button class="delete-btn" data-id="${t.id}" title="Delete transaction">✕</button>
      </td>
    `;

    tr.querySelector('.delete-btn').onclick = async () => {
      if (confirm(`Delete transaction "${t.merchant}"?`)) {
        await apiClient.deleteTransaction(t.id);
        const updatedList = state.transactions.filter(item => item.id !== t.id);
        stateManager.set({ transactions: updatedList });
        showToast('Transaction deleted successfully', 'info');
      }
    };

    tbody.appendChild(tr);
  });

  const countBadge = document.getElementById('transactionCountBadge');
  if (countBadge) countBadge.textContent = `${filtered.length} entries`;
}

// Master Refresh
function refreshUI(state) {
  updateMetricCards(state);
  renderTransactionsTable(state);

  // Dynamic Charts
  const allowance = state.profile.monthly_allowance_rupees || 5000;
  renderCategoryChart(state.categories, state.transactions);
  renderTrendChart(allowance, state.transactions);

  // Budget Monitor
  renderBudgetMonitor(state.categories, state.transactions, async () => {
    const fresh = await apiClient.getInitialData();
    stateManager.set(fresh);
  });

  // Burn Rate Estimator
  const burnRate = computeBurnRateMetrics(state.transactions, allowance);
  updateBurnRateUI(burnRate);

  // Gamified Badges
  renderSavingsBadges(state.badges);

  // Online / Offline Status Indicator
  const netStatus = document.getElementById('networkStatusPill');
  if (netStatus) {
    if (state.isOnline) {
      netStatus.className = 'network-pill pill-online';
      netStatus.innerHTML = `● Online (SQLite Sync Active)`;
    } else {
      netStatus.className = 'network-pill pill-offline';
      netStatus.innerHTML = `● Offline (IndexedDB Active)`;
    }
  }
}

// Initialize Application
async function initApp() {
  // Pre-fill today's date
  const dateInput = document.getElementById('date');
  if (dateInput) dateInput.value = new Date().toISOString().split('T')[0];

  // Load initial data
  const initial = await apiClient.getInitialData();
  
  // Set default categories if empty
  const defaultCats = [
    { id: 'food', name: 'Food & Dining', icon: '🍔', monthly_budget_paise: 150000 },
    { id: 'books', name: 'Books & Study', icon: '📚', monthly_budget_paise: 100000 },
    { id: 'rent', name: 'Rent & Hostel', icon: '🏠', monthly_budget_paise: 200000 },
    { id: 'entertainment', name: 'Entertainment', icon: '🎬', monthly_budget_paise: 80000 },
    { id: 'utilities', name: 'Bills & Utilities', icon: '⚡', monthly_budget_paise: 50000 },
    { id: 'transport', name: 'Transport & Metro', icon: '🚇', monthly_budget_paise: 60000 },
    { id: 'other', name: 'Personal & Other', icon: '🛍️', monthly_budget_paise: 40000 }
  ];

  stateManager.set({
    profile: initial.profile || { monthly_allowance_rupees: 5000 },
    transactions: initial.transactions || [],
    categories: (initial.budgets && initial.budgets.length) ? initial.budgets : defaultCats,
    badges: initial.badges || [
      { id: '1', title: 'Thrifty Scholar', description: 'Weekly spending < 25% of allowance', icon: '🎓', unlocked: 1 },
      { id: '2', title: 'Budget Ninja', description: 'Zero category threshold breaches', icon: '🥷', unlocked: 1 },
      { id: '3', title: 'Mess Master', description: 'Logged 5+ student mess / canteen meals', icon: '🍲', unlocked: 1 },
      { id: '4', title: 'Rainy Day Hero', description: 'Maintained positive cash reserve', icon: '🛡️', unlocked: 1 },
      { id: '5', title: 'Audit Champion', description: 'Exported monthly CSV report', icon: '📊', unlocked: 0 }
    ],
    isOnline: navigator.onLine
  });

  // Subscribe UI to reactive state updates
  stateManager.subscribe(refreshUI);
  refreshUI(stateManager.get());

  // Form submission: Add Transaction
  const addForm = document.getElementById('transactionForm');
  if (addForm) {
    addForm.onsubmit = async (e) => {
      e.preventDefault();
      const merchant = document.getElementById('merchant').value.trim();
      const amount = Number(document.getElementById('amount').value);
      const type = document.getElementById('type').value;
      const category = document.getElementById('category').value;
      const payment = document.getElementById('payment').value;
      const date = document.getElementById('date').value;
      const notes = document.getElementById('notes')?.value.trim() || '';

      if (!merchant || amount <= 0 || !date) {
        showToast('Please enter a valid merchant, date, and positive amount.', 'danger');
        return;
      }

      const res = await apiClient.createTransaction({
        merchant,
        amount,
        type,
        category,
        payment,
        date,
        notes
      });

      if (res.success) {
        const state = stateManager.get();
        stateManager.set({
          transactions: [res.data, ...state.transactions]
        });

        // Reset form
        document.getElementById('merchant').value = '';
        document.getElementById('amount').value = '';
        if (document.getElementById('notes')) document.getElementById('notes').value = '';

        showToast('Transaction logged successfully!', 'success');

        // Check for budget alert notification
        if (res.budgetAlert) {
          showToast(res.budgetAlert.message, res.budgetAlert.threshold >= 100 ? 'danger' : 'warning');
        }
      } else {
        showToast(res.errors?.join(', ') || 'Failed to add transaction', 'danger');
      }
    };
  }

  // Multi-Filter controls
  const searchInput = document.getElementById('search');
  const typeFilter = document.getElementById('filterType');
  const catFilter = document.getElementById('filterCategory');
  const startDateFilter = document.getElementById('startDate');
  const endDateFilter = document.getElementById('endDate');

  function updateFilters() {
    const s = stateManager.get();
    stateManager.set({
      activeFilters: {
        ...s.activeFilters,
        search: searchInput ? searchInput.value : '',
        type: typeFilter ? typeFilter.value : 'All',
        category: catFilter ? catFilter.value : 'All',
        startDate: startDateFilter ? startDateFilter.value : '',
        endDate: endDateFilter ? endDateFilter.value : ''
      }
    });
  }

  if (searchInput) searchInput.oninput = updateFilters;
  if (typeFilter) typeFilter.onchange = updateFilters;
  if (catFilter) catFilter.onchange = updateFilters;
  if (startDateFilter) startDateFilter.onchange = updateFilters;
  if (endDateFilter) endDateFilter.onchange = updateFilters;

  // CSV Export Button
  const csvBtn = document.getElementById('exportCsvBtn');
  if (csvBtn) {
    csvBtn.onclick = () => {
      const state = stateManager.get();
      const res = exportTransactionsToCSV(state.transactions, state.profile);
      if (res.success) {
        showToast(`Exported ${res.count} transactions to CSV audit report!`, 'success');
      } else {
        showToast(res.message, 'warning');
      }
    };
  }

  // Load 60-Day Student Archetype Data button
  const seedBtn = document.getElementById('seedArchetypeBtn');
  if (seedBtn) {
    seedBtn.onclick = async () => {
      if (confirm('Load 60-day student archetype transactions (mess bills, book purchases, chai payments, stipend)?')) {
        const seedRes = await apiClient.seedArchetypeData();
        if (seedRes.success) {
          const fresh = await apiClient.getInitialData();
          stateManager.set(fresh);
          showToast('Loaded 60-day student dataset successfully!', 'success');
        }
      }
    };
  }

  // Allowance quick-updater
  const editAllowanceBtn = document.getElementById('editAllowanceBtn');
  if (editAllowanceBtn) {
    editAllowanceBtn.onclick = async () => {
      const cur = stateManager.get().profile.monthly_allowance_rupees || 5000;
      const input = prompt('Enter your monthly student pocket money / allowance (₹):', cur);
      if (input !== null && !isNaN(Number(input)) && Number(input) >= 0) {
        await apiClient.updateProfile({ monthly_allowance: Number(input) });
        const fresh = await apiClient.getInitialData();
        stateManager.set(fresh);
        showToast(`Allowance updated to ₹${Number(input).toFixed(2)}`, 'success');
      }
    };
  }

  // Setup Peer Expense Splitter
  setupSplitCalculator();

  // Setup Receipt OCR scanner
  setupReceiptScanner((parsed) => {
    document.getElementById('merchant').value = parsed.merchant;
    document.getElementById('amount').value = parsed.amount;
    document.getElementById('category').value = parsed.category;
    document.getElementById('payment').value = parsed.payment;
    document.getElementById('date').value = parsed.date;
    document.getElementById('type').value = parsed.type;
    showToast(`Scanned receipt: ₹${parsed.amount} from ${parsed.merchant}`, 'info');
  });

  // Offline / Online Event Listeners
  window.addEventListener('online', async () => {
    stateManager.set({ isOnline: true });
    showToast('Network reconnected! Synchronizing offline ledger to backend...', 'info');
    const syncRes = await apiClient.syncOfflineData();
    if (syncRes) {
      showToast('Synchronization complete! SQLite database updated.', 'success');
      const fresh = await apiClient.getInitialData();
      stateManager.set(fresh);
    }
  });

  window.addEventListener('offline', () => {
    stateManager.set({ isOnline: false });
    showToast('Offline mode active. All changes will be saved to IndexedDB.', 'warning');
  });
}

// Start app on DOM ready
document.addEventListener('DOMContentLoaded', initApp);
