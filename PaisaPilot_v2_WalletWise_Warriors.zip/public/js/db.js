/**
 * Browser IndexedDB Offline-First Storage Layer
 * Single source of truth on the client, with queue for offline optimistic mutations.
 */

const DB_NAME = 'PaisaPilot_IndexedDB';
const DB_VERSION = 1;

class OfflineStorage {
  constructor() {
    this.db = null;
    this.ready = this.init();
  }

  async init() {
    return new Promise((resolve, reject) => {
      if (!window.indexedDB) {
        console.warn('IndexedDB not supported, falling back to LocalStorage.');
        resolve(null);
        return;
      }

      const request = window.indexedDB.open(DB_NAME, DB_VERSION);

      request.onupgradeneeded = (event) => {
        const db = event.target.result;

        // Transactions Store
        if (!db.objectStoreNames.contains('transactions')) {
          const txStore = db.createObjectStore('transactions', { keyPath: 'id' });
          txStore.createIndex('date', 'date', { unique: false });
          txStore.createIndex('category_id', 'category_id', { unique: false });
          txStore.createIndex('type', 'type', { unique: false });
        }

        // Categories / Budgets Store
        if (!db.objectStoreNames.contains('categories')) {
          db.createObjectStore('categories', { keyPath: 'id' });
        }

        // Offline mutation queue
        if (!db.objectStoreNames.contains('sync_queue')) {
          db.createObjectStore('sync_queue', { autoIncrement: true });
        }

        // Profile store
        if (!db.objectStoreNames.contains('profile')) {
          db.createObjectStore('profile', { keyPath: 'id' });
        }
      };

      request.onsuccess = (event) => {
        this.db = event.target.result;
        resolve(this.db);
      };

      request.onerror = (event) => {
        console.error('IndexedDB open error:', event.target.error);
        resolve(null);
      };
    });
  }

  async getAllTransactions() {
    await this.ready;
    if (!this.db) {
      return JSON.parse(localStorage.getItem('paisa_transactions_fallback') || '[]');
    }

    return new Promise((resolve) => {
      const tx = this.db.transaction('transactions', 'readonly');
      const store = tx.objectStore('transactions');
      const req = store.getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => resolve([]);
    });
  }

  async saveTransactions(transactions) {
    await this.ready;
    localStorage.setItem('paisa_transactions_fallback', JSON.stringify(transactions));

    if (!this.db) return;

    return new Promise((resolve) => {
      const tx = this.db.transaction('transactions', 'readwrite');
      const store = tx.objectStore('transactions');
      store.clear();
      for (const t of transactions) {
        store.put(t);
      }
      tx.oncomplete = () => resolve(true);
      tx.onerror = () => resolve(false);
    });
  }

  async putTransaction(transaction) {
    await this.ready;
    if (!this.db) {
      const list = JSON.parse(localStorage.getItem('paisa_transactions_fallback') || '[]');
      const idx = list.findIndex(t => t.id === transaction.id);
      if (idx >= 0) list[idx] = transaction;
      else list.push(transaction);
      localStorage.setItem('paisa_transactions_fallback', JSON.stringify(list));
      return;
    }

    return new Promise((resolve) => {
      const tx = this.db.transaction('transactions', 'readwrite');
      const store = tx.objectStore('transactions');
      store.put(transaction);
      tx.oncomplete = () => resolve(true);
      tx.onerror = () => resolve(false);
    });
  }

  async deleteTransaction(id) {
    await this.ready;
    if (!this.db) {
      let list = JSON.parse(localStorage.getItem('paisa_transactions_fallback') || '[]');
      list = list.filter(t => t.id !== id);
      localStorage.setItem('paisa_transactions_fallback', JSON.stringify(list));
      return;
    }

    return new Promise((resolve) => {
      const tx = this.db.transaction('transactions', 'readwrite');
      const store = tx.objectStore('transactions');
      store.delete(id);
      tx.oncomplete = () => resolve(true);
      tx.onerror = () => resolve(false);
    });
  }

  async queueMutation(mutation) {
    await this.ready;
    if (!this.db) {
      const q = JSON.parse(localStorage.getItem('paisa_sync_queue') || '[]');
      q.push(mutation);
      localStorage.setItem('paisa_sync_queue', JSON.stringify(q));
      return;
    }

    return new Promise((resolve) => {
      const tx = this.db.transaction('sync_queue', 'readwrite');
      const store = tx.objectStore('sync_queue');
      store.add(mutation);
      tx.oncomplete = () => resolve(true);
      tx.onerror = () => resolve(false);
    });
  }

  async getSyncQueue() {
    await this.ready;
    if (!this.db) {
      return JSON.parse(localStorage.getItem('paisa_sync_queue') || '[]');
    }

    return new Promise((resolve) => {
      const tx = this.db.transaction('sync_queue', 'readonly');
      const store = tx.objectStore('sync_queue');
      const req = store.getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => resolve([]);
    });
  }

  async clearSyncQueue() {
    await this.ready;
    localStorage.removeItem('paisa_sync_queue');
    if (!this.db) return;

    return new Promise((resolve) => {
      const tx = this.db.transaction('sync_queue', 'readwrite');
      const store = tx.objectStore('sync_queue');
      store.clear();
      tx.oncomplete = () => resolve(true);
      tx.onerror = () => resolve(false);
    });
  }
}

export const offlineStorage = new OfflineStorage();
