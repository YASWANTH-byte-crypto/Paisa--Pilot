/**
 * RFC-4180 Compliant CSV Export Utility
 * Converts transaction histories into external spreadsheet audit reports.
 */

export function exportTransactionsToCSV(transactions, profile = { name: 'Student' }) {
  if (!transactions || transactions.length === 0) {
    return { success: false, message: 'No transactions available to export.' };
  }

  const headers = [
    'Transaction ID',
    'Date',
    'Merchant / Description',
    'Category',
    'Type',
    'Payment Method',
    'Amount (₹)',
    'Amount in Paise',
    'Notes'
  ];

  const escapeCSV = (value) => {
    if (value === null || value === undefined) return '""';
    const str = String(value).replace(/"/g, '""');
    return `"${str}"`;
  };

  const rows = transactions.map(t => {
    const amountRupees = (t.amount_paise ? (t.amount_paise / 100) : Number(t.amount || 0)).toFixed(2);
    const paise = t.amount_paise || Math.round(Number(t.amount || 0) * 100);

    return [
      escapeCSV(t.id),
      escapeCSV(t.date),
      escapeCSV(t.merchant),
      escapeCSV(t.category_name || t.category_id || t.category || 'Other'),
      escapeCSV(t.type),
      escapeCSV(t.payment_method || t.payment || 'UPI'),
      escapeCSV(amountRupees),
      escapeCSV(paise),
      escapeCSV(t.notes || '')
    ].join(',');
  });

  // Calculate totals for audit footer
  const totalIncome = transactions
    .filter(t => t.type === 'Income')
    .reduce((sum, t) => sum + (t.amount_paise ? t.amount_paise / 100 : Number(t.amount || 0)), 0);

  const totalExpense = transactions
    .filter(t => t.type === 'Expense')
    .reduce((sum, t) => sum + (t.amount_paise ? t.amount_paise / 100 : Number(t.amount || 0)), 0);

  const netSavings = totalIncome - totalExpense;

  const summaryRows = [
    '',
    `"--- AUDIT SUMMARY REPORT ---"`,
    `"Student Name:",${escapeCSV(profile.name || 'Student')}`,
    `"Export Timestamp:",${escapeCSV(new Date().toISOString())}`,
    `"Total Recorded Income (₹):",${escapeCSV(totalIncome.toFixed(2))}`,
    `"Total Recorded Expenses (₹):",${escapeCSV(totalExpense.toFixed(2))}`,
    `"Net Cash Flow (₹):",${escapeCSV(netSavings.toFixed(2))}`
  ];

  const csvContent = '\uFEFF' + [headers.join(','), ...rows, ...summaryRows].join('\r\n');

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');

  const dateStr = new Date().toISOString().split('T')[0];
  link.href = url;
  link.download = `PaisaPilot_Student_Audit_${dateStr}.csv`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);

  return { success: true, count: transactions.length };
}
