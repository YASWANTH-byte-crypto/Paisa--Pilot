/**
 * PaisaPilot Reactive State Management
 */

class AppState {
  constructor() {
    this.state = {
      profile: {
        name: 'Arjun Sharma',
        college: 'MRV College of Engineering',
        monthly_allowance_paise: 500000,
        monthly_allowance_rupees: 5000.00
      },
      transactions: [],
      categories: [],
      budgets: [],
      badges: [],
      analytics: null,
      isOnline: navigator.onLine,
      pendingSyncCount: 0,
      activeFilters: {
        search: '',
        category: 'All',
        type: 'All',
        startDate: '',
        endDate: '',
        sort: 'date',
        order: 'DESC'
      }
    };
    this.listeners = new Set();
  }

  get() {
    return this.state;
  }

  set(partial) {
    this.state = { ...this.state, ...partial };
    this.notify();
  }

  subscribe(listener) {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  notify() {
    for (const listener of this.listeners) {
      try {
        listener(this.state);
      } catch (e) {
        console.error('State subscriber error:', e);
      }
    }
  }
}

export const stateManager = new AppState();
