/**
 * Budget Cap Threshold Monitor (SRS 3.3)
 * Configurable category-wise budget caps with visual progress bars and alert thresholds at 80% and 100% capacity.
 */

import { apiClient } from './api.js';

export function renderBudgetMonitor(categories, transactions, onBudgetChanged) {
  const container = document.getElementById('budgetCardsContainer');
  const alertBannerContainer = document.getElementById('budgetAlertBanners');
  if (!container) return;

  container.innerHTML = '';
  if (alertBannerContainer) alertBannerContainer.innerHTML = '';

  const activeAlerts = [];
  const currentMonth = new Date().toISOString().slice(0, 7); // 'YYYY-MM'

  categories.forEach(cat => {
    // Current month spent for this category
    const spentPaise = transactions
      .filter(t => {
        const catMatch = t.category_id === cat.id || (t.category && t.category.toLowerCase() === cat.id);
        const monthMatch = t.date && t.date.startsWith(currentMonth);
        return t.type === 'Expense' && catMatch && monthMatch;
      })
      .reduce((sum, t) => sum + (t.amount_paise || Math.round(Number(t.amount || 0) * 100)), 0);

    const budgetPaise = cat.monthly_budget_paise || 0;
    const spentRupees = spentPaise / 100;
    const budgetRupees = budgetPaise / 100;
    const percentage = budgetRupees > 0 ? Math.round((spentRupees / budgetRupees) * 100) : 0;

    // Determine status & styling
    let barColor = '#168c88'; // Safe (Teal)
    let badgeClass = 'badge-safe';
    let statusText = 'Normal';

    if (percentage >= 100) {
      barColor = '#e74c3c'; // Danger Red (Breached)
      badgeClass = 'badge-danger';
      statusText = '100% BREACHED';
      activeAlerts.push({
        type: 'danger',
        category: cat.name,
        percentage,
        spent: spentRupees,
        budget: budgetRupees,
        message: `⚠️ CRITICAL BUDGET BREACH: You have spent 100% (₹${spentRupees.toFixed(2)} of ₹${budgetRupees.toFixed(2)}) allocated for ${cat.name}!`
      });
    } else if (percentage >= 80) {
      barColor = '#f39c12'; // Amber (80% Warning)
      badgeClass = 'badge-warning';
      statusText = '80% WARNING';
      activeAlerts.push({
        type: 'warning',
        category: cat.name,
        percentage,
        spent: spentRupees,
        budget: budgetRupees,
        message: `🔔 BUDGET ALERT: You have consumed ${percentage}% of your ${cat.name} monthly limit (₹${spentRupees.toFixed(2)} of ₹${budgetRupees.toFixed(2)}).`
      });
    }

    const card = document.createElement('div');
    card.className = 'budget-card';
    card.innerHTML = `
      <div class="budget-card-header">
        <div class="cat-title">
          <span class="cat-icon">${cat.icon || '🏷️'}</span>
          <strong>${cat.name}</strong>
        </div>
        <span class="status-badge ${badgeClass}">${statusText}</span>
      </div>

      <div class="budget-amounts">
        <span>Spent: <strong>₹${spentRupees.toFixed(2)}</strong></span>
        <span>Cap: <strong>₹${budgetRupees.toFixed(2)}</strong></span>
      </div>

      <div class="progress-track" title="${percentage}% used">
        <div class="progress-fill" style="width: ${Math.min(100, percentage)}%; background-color: ${barColor};"></div>
      </div>

      <div class="budget-card-footer">
        <small>${percentage}% consumed</small>
        <button class="edit-cap-btn" data-cat="${cat.id}" data-cap="${budgetRupees}">Edit Cap ✎</button>
      </div>
    `;

    container.appendChild(card);
  });

  // Render Alert Banners
  if (alertBannerContainer && activeAlerts.length > 0) {
    activeAlerts.forEach(alert => {
      const banner = document.createElement('div');
      banner.className = `alert-banner ${alert.type === 'danger' ? 'alert-danger' : 'alert-warning'}`;
      banner.innerHTML = `
        <div class="alert-content">
          <span class="alert-icon">${alert.type === 'danger' ? '🚨' : '⚠️'}</span>
          <div>
            <strong>${alert.type === 'danger' ? 'Limit Exceeded!' : 'Budget Warning Threshold (80%)!'}</strong>
            <p>${alert.message}</p>
          </div>
        </div>
      `;
      alertBannerContainer.appendChild(banner);
    });
  }

  // Attach Edit Cap listeners
  container.querySelectorAll('.edit-cap-btn').forEach(btn => {
    btn.onclick = async (e) => {
      const catId = e.target.getAttribute('data-cat');
      const currentCap = e.target.getAttribute('data-cap');
      const newCap = prompt(`Enter new monthly budget cap (₹) for ${catId.toUpperCase()}:`, currentCap);
      if (newCap !== null && !isNaN(Number(newCap)) && Number(newCap) >= 0) {
        await apiClient.updateBudget(catId, Number(newCap));
        if (onBudgetChanged) onBudgetChanged();
      }
    };
  });
}
