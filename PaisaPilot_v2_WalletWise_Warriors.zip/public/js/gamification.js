/**
 * Gamified Savings Badges & Milestones Module
 * Rewards students with unlockable badges for responsible micro-budgeting.
 */

export function renderSavingsBadges(badges) {
  const container = document.getElementById('badgesContainer');
  if (!container) return;

  container.innerHTML = '';

  badges.forEach(b => {
    const isUnlocked = b.unlocked === 1 || b.unlocked === true;
    const badgeEl = document.createElement('div');
    badgeEl.className = `badge-item ${isUnlocked ? 'badge-unlocked' : 'badge-locked'}`;
    badgeEl.innerHTML = `
      <div class="badge-icon">${b.icon || '🏅'}</div>
      <div class="badge-info">
        <h4>${b.title}</h4>
        <p>${b.description}</p>
        <span class="badge-status-pill">${isUnlocked ? 'Unlocked 🎉' : 'Locked 🔒'}</span>
      </div>
    `;
    container.appendChild(badgeEl);
  });
}
