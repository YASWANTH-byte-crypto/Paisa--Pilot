/**
 * Peer Expense Splitting & UPI Deep-Link Generator
 * Stretch Feature: Calculates individual shares for shared mess/canteen bills
 * and renders direct UPI deep-links (upi://pay) + dynamic QR codes.
 */

export function setupSplitCalculator() {
  const calcBtn = document.getElementById('calculateSplitBtn');
  if (!calcBtn) return;

  calcBtn.onclick = () => {
    const totalAmount = Number(document.getElementById('splitTotalAmount').value);
    const numPeople = Number(document.getElementById('splitNumPeople').value);
    const payeeVpa = (document.getElementById('splitUpiVpa').value || 'student@upi').trim();
    const payeeName = (document.getElementById('splitPayeeName').value || 'Hostel Mess').trim();
    const note = (document.getElementById('splitNote').value || 'Shared Canteen Bill').trim();

    const resultBox = document.getElementById('splitResultBox');
    if (isNaN(totalAmount) || totalAmount <= 0 || isNaN(numPeople) || numPeople < 1) {
      alert('Please enter valid total bill amount and number of students.');
      return;
    }

    const perPersonShare = (totalAmount / numPeople).toFixed(2);

    // Generate Standard UPI Deep Link (RFC specification)
    // upi://pay?pa=VPA&pn=NAME&am=AMOUNT&cu=INR&tn=NOTE
    const upiLink = `upi://pay?pa=${encodeURIComponent(payeeVpa)}&pn=${encodeURIComponent(payeeName)}&am=${perPersonShare}&cu=INR&tn=${encodeURIComponent(note)}`;

    // Generate QR Code URL using public fast SVG QR API
    const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=${encodeURIComponent(upiLink)}`;

    resultBox.style.display = 'block';
    resultBox.innerHTML = `
      <div class="split-card">
        <div class="split-summary">
          <h4>💰 Share per Student: <span class="highlight">₹${perPersonShare}</span></h4>
          <p>Total Bill: ₹${totalAmount.toFixed(2)} split among ${numPeople} people</p>
        </div>

        <div class="upi-actions">
          <a href="${upiLink}" class="upi-pay-btn">
            📱 Open in UPI App (GPay / PhonePe / Paytm)
          </a>
          <button class="copy-upi-btn" id="copyUpiLinkBtn">📋 Copy UPI Link</button>
        </div>

        <div class="qr-container">
          <p><small>Scan with any UPI App to pay ₹${perPersonShare}:</small></p>
          <img src="${qrUrl}" alt="UPI QR Code" class="upi-qr-image" onerror="this.style.display='none'">
        </div>
      </div>
    `;

    document.getElementById('copyUpiLinkBtn').onclick = () => {
      navigator.clipboard.writeText(upiLink).then(() => {
        alert('UPI deep link copied to clipboard!');
      });
    };
  };
}
