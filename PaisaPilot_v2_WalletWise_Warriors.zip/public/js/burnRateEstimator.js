/**
 * Predictive Burn Rate Estimator Algorithm
 * Projects month-end balance based on past 7-day spending velocity.
 */

export function computeBurnRateMetrics(transactions, allowance, referenceDate = new Date()) {
  const now = new Date(referenceDate);
  const totalDaysInMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate();
  const currentDay = now.getDate();
  const daysRemaining = Math.max(1, totalDaysInMonth - currentDay);

  // Past 7 days cutoff
  const sevenDaysAgo = new Date(now);
  sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 6);
  sevenDaysAgo.setHours(0, 0, 0, 0);

  const startIso = sevenDaysAgo.toISOString().split('T')[0];
  const endIso = now.toISOString().split('T')[0];

  const recentExpenses = transactions.filter(t => {
    return t.type === 'Expense' && t.date >= startIso && t.date <= endIso;
  });

  const totalSpentLast7Days = recentExpenses.reduce((sum, t) => {
    return sum + (t.amount_paise ? t.amount_paise / 100 : Number(t.amount || 0));
  }, 0);

  // Moving average daily velocity
  const dailyVelocity = totalSpentLast7Days / 7;

  // Current balance
  const totalIncome = transactions
    .filter(t => t.type === 'Income')
    .reduce((sum, t) => sum + (t.amount_paise ? t.amount_paise / 100 : Number(t.amount || 0)), 0);

  const totalExpenses = transactions
    .filter(t => t.type === 'Expense')
    .reduce((sum, t) => sum + (t.amount_paise ? t.amount_paise / 100 : Number(t.amount || 0)), 0);

  const currentBalance = allowance + totalIncome - totalExpenses;

  // Projected month-end balance
  const projectedBalance = currentBalance - (dailyVelocity * daysRemaining);

  // Runway days until balance reaches zero
  const runwayDays = dailyVelocity > 0 ? Math.max(0, Math.floor(currentBalance / dailyVelocity)) : (currentBalance > 0 ? 99 : 0);

  // Daily safe-spend allowance
  const safeDailySpend = currentBalance > 0 ? Math.floor(currentBalance / daysRemaining) : 0;

  // Diagnostic status
  let status = 'HEALTHY';
  let badgeClass = 'badge-safe';
  let advice = `You are spending ~₹${dailyVelocity.toFixed(0)}/day. Safe allowance is ₹${safeDailySpend.toFixed(0)}/day. Projected month-end balance is ₹${projectedBalance.toFixed(2)}.`;

  if (dailyVelocity > safeDailySpend * 1.5 && safeDailySpend > 0) {
    status = 'HIGH BURN RATE';
    badgeClass = 'badge-danger';
    advice = `⚠️ Warning: Spending velocity (₹${dailyVelocity.toFixed(0)}/day) exceeds safe allowance (₹${safeDailySpend.toFixed(0)}/day). Funds will exhaust in ${runwayDays} days!`;
  } else if (dailyVelocity > safeDailySpend && safeDailySpend > 0) {
    status = 'MODERATE VELOCITY';
    badgeClass = 'badge-warning';
    advice = `Caution: spending is slightly above safe daily budget. Consider throttling non-essential dining/entertainment.`;
  }

  return {
    daysRemaining,
    dailyVelocity,
    safeDailySpend,
    projectedBalance,
    runwayDays,
    status,
    badgeClass,
    advice,
    currentBalance
  };
}

export function updateBurnRateUI(metrics) {
  const velocityEl = document.getElementById('dailyVelocityDisplay');
  const runwayEl = document.getElementById('runwayDisplay');
  const projectedEl = document.getElementById('projectedBalanceDisplay');
  const safeDailyEl = document.getElementById('safeDailySpendDisplay');
  const adviceEl = document.getElementById('burnRateAdvice');
  const statusBadge = document.getElementById('burnRateStatusBadge');

  if (velocityEl) velocityEl.textContent = `₹${metrics.dailyVelocity.toFixed(2)} / day`;
  if (runwayEl) runwayEl.textContent = `${metrics.runwayDays} Days`;
  if (projectedEl) {
    projectedEl.textContent = `₹${metrics.projectedBalance.toFixed(2)}`;
    projectedEl.style.color = metrics.projectedBalance < 0 ? '#e74c3c' : '#168c88';
  }
  if (safeDailyEl) safeDailyEl.textContent = `₹${metrics.safeDailySpend.toFixed(2)} / day`;
  if (adviceEl) adviceEl.textContent = metrics.advice;
  if (statusBadge) {
    statusBadge.textContent = metrics.status;
    statusBadge.className = `status-badge ${metrics.badgeClass}`;
  }
}
