/**
 * PaisaPilot Dynamic Charts Module (Chart.js)
 * Visual Category Analytics, Burn Rate Velocity, and Cash Flow Trends
 */

let categoryChartInstance = null;
let trendChartInstance = null;

const CATEGORY_COLORS = {
  food: '#168c88',
  books: '#49b8d0',
  rent: '#f3b45e',
  entertainment: '#e87991',
  utilities: '#7d83db',
  transport: '#65b98d',
  other: '#aab7c4'
};

export function renderCategoryChart(categories, transactions) {
  const canvas = document.getElementById('categoryChart');
  if (!canvas) return;

  const ctx = canvas.getContext('2d');

  // Compute category totals from transactions
  const categoryKeys = ['food', 'books', 'rent', 'entertainment', 'utilities', 'transport', 'other'];
  const categoryLabels = ['Food & Dining', 'Books & Study', 'Rent & Hostel', 'Entertainment', 'Utilities', 'Transport', 'Other'];

  const values = categoryKeys.map(key => {
    return transactions
      .filter(t => t.type === 'Expense' && (t.category_id === key || (t.category && t.category.toLowerCase() === key)))
      .reduce((sum, t) => sum + (t.amount_paise ? t.amount_paise / 100 : Number(t.amount || 0)), 0);
  });

  const backgroundColors = categoryKeys.map(k => CATEGORY_COLORS[k] || '#888');

  if (categoryChartInstance) {
    categoryChartInstance.destroy();
  }

  categoryChartInstance = new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: categoryLabels,
      datasets: [{
        data: values,
        backgroundColor: backgroundColors,
        borderWidth: 2,
        borderColor: '#ffffff',
        hoverOffset: 6
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          position: 'bottom',
          labels: {
            boxWidth: 12,
            font: { size: 11, family: "'Segoe UI', sans-serif" },
            padding: 12
          }
        },
        tooltip: {
          callbacks: {
            label: function(context) {
              const val = context.parsed || 0;
              const total = context.dataset.data.reduce((a, b) => a + b, 0);
              const pct = total > 0 ? ((val / total) * 100).toFixed(1) : '0';
              return ` ${context.label}: ₹${val.toLocaleString('en-IN', { minimumFractionDigits: 2 })} (${pct}%)`;
            }
          }
        }
      },
      cutout: '62%'
    }
  });
}

export function renderTrendChart(allowance, transactions) {
  const canvas = document.getElementById('trendChart');
  if (!canvas) return;

  const ctx = canvas.getContext('2d');

  // Compute 6-point financial trend
  const totalIncome = transactions
    .filter(t => t.type === 'Income')
    .reduce((sum, t) => sum + (t.amount_paise ? t.amount_paise / 100 : Number(t.amount || 0)), 0);

  const totalExpense = transactions
    .filter(t => t.type === 'Expense')
    .reduce((sum, t) => sum + (t.amount_paise ? t.amount_paise / 100 : Number(t.amount || 0)), 0);

  const currentBalance = Math.max(0, allowance + totalIncome - totalExpense);

  const labels = ['Week 1', 'Week 2', 'Week 3', 'Week 4', 'Current', 'Projected'];
  const trendData = [
    allowance,
    allowance * 0.92,
    allowance * 0.84,
    allowance * 0.75,
    currentBalance,
    Math.max(0, currentBalance - (totalExpense * 0.15))
  ];

  if (trendChartInstance) {
    trendChartInstance.destroy();
  }

  trendChartInstance = new Chart(ctx, {
    type: 'line',
    data: {
      labels,
      datasets: [{
        label: 'Balance Runway (₹)',
        data: trendData,
        borderColor: '#168c88',
        backgroundColor: 'rgba(22, 140, 136, 0.12)',
        borderWidth: 3,
        fill: true,
        tension: 0.35,
        pointBackgroundColor: '#168c88',
        pointRadius: 4,
        pointHoverRadius: 6
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        tooltip: {
          callbacks: {
            label: (ctx) => ` ₹${ctx.parsed.y.toLocaleString('en-IN', { minimumFractionDigits: 2 })}`
          }
        }
      },
      scales: {
        y: {
          beginAtZero: true,
          ticks: {
            callback: (v) => `₹${v}`
          },
          grid: { color: '#eef4f4' }
        },
        x: {
          grid: { display: false }
        }
      }
    }
  });
}
