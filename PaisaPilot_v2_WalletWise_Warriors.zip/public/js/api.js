/**
 * API Client with Offline Fallback & Optimistic Synchronization
 */

import { offlineStorage } from './db.js';
import { stateManager } from './state.js';

const API_BASE = '/api';

export const apiClient = {
  // Check online status
  isOnline() {
    return navigator.onLine;
  },

  // Fetch full dataset
  async getInitialData() {
    try {
      if (this.isOnline()) {
        const [profileRes, txRes, budgetRes, analyticsRes, badgesRes] = await Promise.all([
          fetch(`${API_BASE}/profile`).then(r => r.json()),
          fetch(`${API_BASE}/transactions`).then(r => r.json()),
          fetch(`${API_BASE}/budgets`).then(r => r.json()),
          fetch(`${API_BASE}/analytics`).then(r => r.json()),
          fetch(`${API_BASE}/badges`).then(r => r.json())
        ]);

        if (txRes.success) {
          await offlineStorage.saveTransactions(txRes.data);
        }

        return {
          profile: profileRes.data,
          transactions: txRes.data,
          budgets: budgetRes.data,
          analytics: analyticsRes,
          badges: badgesRes.badges || []
        };
      }
    } catch (err) {
      console.warn('Network API fetch failed, loading offline cached data:', err);
    }

    // Fallback to offline IndexedDB
    const cachedTransactions = await offlineStorage.getAllTransactions();
    return {
      profile: { name: 'Student', monthly_allowance_paise: 500000, monthly_allowance_rupees: 5000.00 },
      transactions: cachedTransactions,
      budgets: [],
      analytics: null,
      badges: []
    };
  },

  // Add Transaction
  async createTransaction(transaction) {
    if (this.isOnline()) {
      try {
        const res = await fetch(`${API_BASE}/transactions`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(transaction)
        });
        const data = await res.json();
        if (data.success) {
          await offlineStorage.putTransaction(data.data);
          return data;
        }
        throw new Error(data.errors?.join(', ') || data.error || 'Creation failed');
      } catch (err) {
        console.warn('Online creation failed, queuing offline:', err);
      }
    }

    // Offline optimistic path
    const localTx = {
      ...transaction,
      id: transaction.id || ('offline-' + Date.now()),
      amount_paise: Math.round(Number(transaction.amount) * 100),
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };

    await offlineStorage.putTransaction(localTx);
    await offlineStorage.queueMutation({ action: 'create', data: localTx });

    return {
      success: true,
      data: localTx,
      isOffline: true
    };
  },

  // Delete Transaction
  async deleteTransaction(id) {
    if (this.isOnline()) {
      try {
        const res = await fetch(`${API_BASE}/transactions/${id}`, { method: 'DELETE' });
        const data = await res.json();
        if (data.success) {
          await offlineStorage.deleteTransaction(id);
          return data;
        }
      } catch (err) {
        console.warn('Online delete failed, queuing offline:', err);
      }
    }

    await offlineStorage.deleteTransaction(id);
    await offlineStorage.queueMutation({ action: 'delete', id });
    return { success: true, isOffline: true };
  },

  // Update Category Budget Cap
  async updateBudget(categoryId, limitRupees) {
    if (this.isOnline()) {
      const res = await fetch(`${API_BASE}/budgets/${categoryId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ limit: limitRupees })
      });
      return await res.json();
    }
    return { success: true, isOffline: true };
  },

  // Update Profile
  async updateProfile(profileData) {
    if (this.isOnline()) {
      const res = await fetch(`${API_BASE}/profile`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(profileData)
      });
      return await res.json();
    }
    return { success: true, isOffline: true };
  },

  // Sync Offline Queue to Backend
  async syncOfflineData() {
    if (!this.isOnline()) return null;

    const queue = await offlineStorage.getSyncQueue();
    if (queue.length === 0) return null;

    const created = queue.filter(q => q.action === 'create').map(q => q.data);
    const updated = queue.filter(q => q.action === 'update').map(q => q.data);
    const deleted = queue.filter(q => q.action === 'delete').map(q => q.id);

    try {
      const res = await fetch(`${API_BASE}/sync`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ created, updated, deleted })
      });
      const result = await res.json();
      if (result.success) {
        await offlineStorage.clearSyncQueue();
        if (result.serverTransactions) {
          await offlineStorage.saveTransactions(result.serverTransactions);
        }
        return result;
      }
    } catch (err) {
      console.error('Batch sync failed:', err);
    }
    return null;
  },

  // Seed 60-day archetype data
  async seedArchetypeData() {
    const res = await fetch(`${API_BASE}/demo/seed`, { method: 'POST' });
    return await res.json();
  }
};
