const test = require('node:test');
const assert = require('node:assert/strict');
const { validateTransaction, validateBudget } = require('../utils/validation');

test('Validation: accepts valid transaction payloads', () => {
  const payload = {
    merchant: 'Engineering Books Stall',
    amount: 850,
    type: 'Expense',
    category: 'books',
    payment: 'UPI',
    date: '2026-05-15'
  };

  const result = validateTransaction(payload);
  assert.equal(result.isValid, true);
  assert.equal(result.errors.length, 0);
  assert.equal(result.data.category_id, 'books');
});

test('Validation: rejects invalid transactions', () => {
  const invalidPayload = {
    merchant: '',
    amount: -50,
    type: 'InvalidType',
    category: 'unknown_cat',
    date: '15/05/2026' // wrong format
  };

  const result = validateTransaction(invalidPayload);
  assert.equal(result.isValid, false);
  assert.ok(result.errors.length >= 4);
});

test('Validation: validates budget caps correctly', () => {
  const validBudget = validateBudget({ category: 'food', limit: 1500 });
  assert.equal(validBudget.isValid, true);
  assert.equal(validBudget.data.monthly_budget_paise, 150000);

  const invalidBudget = validateBudget({ category: 'non_existent', limit: -100 });
  assert.equal(invalidBudget.isValid, false);
});
