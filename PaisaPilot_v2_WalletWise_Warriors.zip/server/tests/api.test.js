const test = require('node:test');
const assert = require('node:assert/strict');
const { getDatabase } = require('../db/database');
const { generate60DayData } = require('../db/seed');
const { toPaise } = require('../utils/currency');

test('Database & Schema: initializes tables properly', () => {
  const db = getDatabase();
  const tables = db.prepare(`SELECT name FROM sqlite_master WHERE type='table'`).all().map(r => r.name);
  
  assert.ok(tables.includes('profiles'));
  assert.ok(tables.includes('categories'));
  assert.ok(tables.includes('transactions'));
  assert.ok(tables.includes('budget_alerts'));
  assert.ok(tables.includes('savings_badges'));
});

test('Student Profile: profile exists with default allowance', () => {
  const db = getDatabase();
  const profile = db.prepare('SELECT * FROM profiles WHERE id = 1').get();
  assert.ok(profile);
  assert.equal(profile.monthly_allowance_paise, 500000); // ₹5,000.00
});

test('Transactions & Budget Alert: triggers 80% and 100% threshold detection', () => {
  const db = getDatabase();
  // Set budget for food to ₹1,000 (100,000 paise)
  db.prepare('UPDATE categories SET monthly_budget_paise = ? WHERE id = ?').run(100000, 'food');
  
  const spentPaise = 85000;
  const budgetPaise = 100000;
  const percentage = Math.round((spentPaise / budgetPaise) * 100);
  
  assert.equal(percentage, 85);
  assert.ok(percentage >= 80 && percentage < 100);

  // Insert another ₹200 expense -> 105% capacity (triggers 100% critical breach)
  const totalSpent = 105000;
  const newPercentage = Math.round((totalSpent / budgetPaise) * 100);
  assert.equal(newPercentage, 105);
  assert.ok(newPercentage >= 100);
});

test('Seed Data: generates realistic 60-day student transactions', () => {
  const count = generate60DayData();
  assert.ok(count >= 20);

  const db = getDatabase();
  const totalInDb = db.prepare('SELECT COUNT(*) as total FROM transactions').get().total;
  assert.equal(totalInDb, count);

  // Check categories exist in transactions
  const foodCount = db.prepare('SELECT COUNT(*) as total FROM transactions WHERE category_id = ?').get('food').total;
  assert.ok(foodCount > 0);
});
