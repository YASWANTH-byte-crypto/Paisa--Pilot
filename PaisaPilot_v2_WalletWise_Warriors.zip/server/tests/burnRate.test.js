const test = require('node:test');
const assert = require('node:assert/strict');
const { calculateBurnRate } = require('../utils/burnRate');
const { toPaise } = require('../utils/currency');

test('Burn Rate Estimator: calculates 7-day velocity and daily safe spend', () => {
  const fixedDate = new Date('2026-05-15T12:00:00Z');
  // 31 days in May. Day 15 -> 16 days remaining.
  
  // 7 days of expenses: 100, 150, 200, 50, 100, 50, 50 = ₹700 total = ₹100/day velocity
  const sampleExpenses = [
    { type: 'Expense', amount_paise: toPaise(100), date: '2026-05-15' },
    { type: 'Expense', amount_paise: toPaise(150), date: '2026-05-14' },
    { type: 'Expense', amount_paise: toPaise(200), date: '2026-05-13' },
    { type: 'Expense', amount_paise: toPaise(50), date: '2026-05-12' },
    { type: 'Expense', amount_paise: toPaise(100), date: '2026-05-11' },
    { type: 'Expense', amount_paise: toPaise(50), date: '2026-05-10' },
    { type: 'Expense', amount_paise: toPaise(50), date: '2026-05-09' }
  ];

  const currentBalancePaise = toPaise(3000); // ₹3,000 balance
  const result = calculateBurnRate(sampleExpenses, currentBalancePaise, fixedDate);

  assert.equal(result.totalSpentLast7DaysPaise, toPaise(700));
  assert.equal(result.dailyVelocityPaise, toPaise(100)); // ₹100/day
  assert.ok(result.daysRemaining > 0);
  assert.equal(result.runwayDays, 30); // 3000 / 100 = 30 days of runway
  assert.equal(result.status, 'HEALTHY');
});

test('Burn Rate Estimator: flags CRITICAL when velocity significantly exceeds safe spend', () => {
  const fixedDate = new Date('2026-05-15T12:00:00Z');
  // High daily expense of ₹600/day over past 7 days with only ₹500 remaining balance
  const heavyExpenses = [
    { type: 'Expense', amount_paise: toPaise(4200), date: '2026-05-15' }
  ];

  const smallBalancePaise = toPaise(500); // ₹500 balance remaining
  const result = calculateBurnRate(heavyExpenses, smallBalancePaise, fixedDate);

  assert.equal(result.dailyVelocityPaise, toPaise(600));
  assert.equal(result.status, 'CRITICAL');
  assert.ok(result.runwayDays <= 1);
});
