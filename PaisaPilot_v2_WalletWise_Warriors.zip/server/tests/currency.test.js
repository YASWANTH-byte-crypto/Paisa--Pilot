const test = require('node:test');
const assert = require('node:assert/strict');
const { toPaise, toRupees, formatRupees, addPaise, subPaise } = require('../utils/currency');

test('Currency Utility: toPaise converts rupees accurately', () => {
  assert.equal(toPaise(100), 10000);
  assert.equal(toPaise(19.99), 1999);
  assert.equal(toPaise(0.1 + 0.2), 30); // Solves IEEE 754 precision trap
  assert.equal(toPaise('₹ 850.50'), 85050);
  assert.equal(toPaise(null), 0);
  assert.equal(toPaise(undefined), 0);
});

test('Currency Utility: toRupees converts paise to standard decimals', () => {
  assert.equal(toRupees(10000), 100.00);
  assert.equal(toRupees(1999), 19.99);
  assert.equal(toRupees(30), 0.30);
  assert.equal(toRupees(0), 0);
});

test('Currency Utility: formatRupees formats with INR currency format', () => {
  const formatted = formatRupees(500000); // ₹5,000.00
  assert.ok(formatted.includes('5,000.00'));
  assert.ok(formatted.startsWith('₹'));
});

test('Currency Utility: addPaise & subPaise perform exact integer calculations', () => {
  const sum = addPaise(toPaise(10.10), toPaise(20.20), toPaise(30.30));
  assert.equal(sum, 6060); // Exactly ₹60.60, zero floating drift

  const diff = subPaise(sum, toPaise(15.10));
  assert.equal(diff, 4550); // Exactly ₹45.50
});
