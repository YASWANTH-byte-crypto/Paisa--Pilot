/**
 * PaisaPilot Currency Utility - Integer Paise Precision
 * Prevents IEEE 754 floating point summation errors by storing and computing
 * all financial amounts strictly as integer paise (1 Rupee = 100 Paise).
 */

function toPaise(amount) {
  if (typeof amount === 'number') {
    if (isNaN(amount) || !isFinite(amount)) return 0;
    return Math.round(amount * 100);
  }
  if (typeof amount === 'string') {
    const cleaned = amount.replace(/[^\d.-]/g, '');
    const num = parseFloat(cleaned);
    if (isNaN(num) || !isFinite(num)) return 0;
    return Math.round(num * 100);
  }
  return 0;
}

function toRupees(paise) {
  const p = Number(paise) || 0;
  return p / 100;
}

function formatRupees(paise, includeSymbol = true) {
  const rupees = toRupees(paise);
  const formatted = new Intl.NumberFormat('en-IN', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  }).format(rupees);

  return includeSymbol ? `₹${formatted}` : formatted;
}

function addPaise(...amounts) {
  return amounts.reduce((sum, val) => sum + (Number(val) || 0), 0);
}

function subPaise(base, ...deductions) {
  return deductions.reduce((sum, val) => sum - (Number(val) || 0), Number(base) || 0);
}

module.exports = {
  toPaise,
  toRupees,
  formatRupees,
  addPaise,
  subPaise
};
