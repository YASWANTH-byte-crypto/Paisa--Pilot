/**
 * Input validation and sanitization middleware for PaisaPilot API
 */

function sanitizeString(str) {
  if (typeof str !== 'string') return '';
  return str.trim().replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

function validateTransaction(body) {
  const errors = [];

  const merchant = sanitizeString(body.merchant || body.description);
  if (!merchant || merchant.length < 2 || merchant.length > 100) {
    errors.push('Merchant description must be between 2 and 100 characters.');
  }

  const amount = Number(body.amount);
  if (isNaN(amount) || amount <= 0 || !isFinite(amount)) {
    errors.push('Amount must be a positive number greater than 0.');
  }

  const validTypes = ['Income', 'Expense'];
  if (!body.type || !validTypes.includes(body.type)) {
    errors.push('Type must be either "Income" or "Expense".');
  }

  const validCategories = ['food', 'books', 'rent', 'entertainment', 'utilities', 'transport', 'other'];
  const categoryId = (body.category_id || body.category || '').toLowerCase();
  if (!categoryId || !validCategories.includes(categoryId)) {
    errors.push(`Category must be one of: ${validCategories.join(', ')}.`);
  }

  const validPayments = ['UPI', 'Cash', 'Card', 'Bank Transfer', 'Other'];
  const paymentMethod = body.payment_method || body.payment || 'UPI';
  if (!validPayments.includes(paymentMethod)) {
    errors.push(`Payment method must be one of: ${validPayments.join(', ')}.`);
  }

  const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
  if (!body.date || !dateRegex.test(body.date)) {
    errors.push('Date must be a valid ISO format (YYYY-MM-DD).');
  }

  return {
    isValid: errors.length === 0,
    errors,
    data: {
      merchant,
      amount,
      type: body.type,
      category_id: categoryId,
      payment_method: paymentMethod,
      date: body.date,
      notes: sanitizeString(body.notes || '')
    }
  };
}

function validateBudget(body) {
  const errors = [];
  const validCategories = ['food', 'books', 'rent', 'entertainment', 'utilities', 'transport', 'other'];
  const categoryId = (body.category_id || body.category || '').toLowerCase();
  
  if (!categoryId || !validCategories.includes(categoryId)) {
    errors.push(`Category must be one of: ${validCategories.join(', ')}.`);
  }

  const limit = Number(body.limit || body.budget);
  if (isNaN(limit) || limit < 0) {
    errors.push('Budget limit must be a non-negative number.');
  }

  return {
    isValid: errors.length === 0,
    errors,
    data: {
      category_id: categoryId,
      monthly_budget_paise: Math.round(limit * 100)
    }
  };
}

module.exports = {
  sanitizeString,
  validateTransaction,
  validateBudget
};
