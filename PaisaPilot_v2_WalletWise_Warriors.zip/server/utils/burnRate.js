/**
 * PaisaPilot Burn Rate Estimator Algorithm
 * Heuristics for calculating spending velocity over the last 7 days,
 * remaining runway, daily safe-spend allowance, and projected month-end balance.
 */

const { toPaise, toRupees } = require('./currency');

function calculateBurnRate(transactions, currentBalancePaise, referenceDate = new Date()) {
  const now = new Date(referenceDate);
  const year = now.getFullYear();
  const month = now.getMonth(); // 0-indexed

  // Total days in current month and day of month
  const totalDaysInMonth = new Date(year, month + 1, 0).getDate();
  const currentDay = now.getDate();
  const daysRemaining = Math.max(1, totalDaysInMonth - currentDay);

  // Past 7 days cutoff (inclusive)
  const sevenDaysAgo = new Date(now);
  sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 6);
  sevenDaysAgo.setHours(0, 0, 0, 0);

  const startIso = sevenDaysAgo.toISOString().split('T')[0];
  const endIso = now.toISOString().split('T')[0];

  // Filter expenses strictly in past 7 days
  const recentExpenses = transactions.filter(t => {
    return t.type === 'Expense' && t.date >= startIso && t.date <= endIso;
  });

  const totalSpentLast7DaysPaise = recentExpenses.reduce((sum, t) => sum + (t.amount_paise || 0), 0);
  
  // Daily velocity (moving average)
  const dailyVelocityPaise = Math.round(totalSpentLast7DaysPaise / 7);

  // Projected expense till month end at current velocity
  const projectedFutureExpensesPaise = dailyVelocityPaise * daysRemaining;
  const projectedBalancePaise = currentBalancePaise - projectedFutureExpensesPaise;

  // Runway in days until pocket money / balance depletes
  let runwayDays = 999;
  if (dailyVelocityPaise > 0) {
    runwayDays = Math.max(0, Math.floor(currentBalancePaise / dailyVelocityPaise));
  } else if (currentBalancePaise <= 0) {
    runwayDays = 0;
  }

  // Safe daily spend allowance: balance spread evenly across remaining days
  const safeDailySpendPaise = currentBalancePaise > 0 ? Math.floor(currentBalancePaise / daysRemaining) : 0;

  // Status diagnosis
  let status = 'HEALTHY';
  let message = 'Spending velocity is well within monthly safe limits.';

  if (dailyVelocityPaise > safeDailySpendPaise * 1.5 && safeDailySpendPaise > 0) {
    status = 'CRITICAL';
    message = `High burn rate! Spending ₹${(dailyVelocityPaise / 100).toFixed(0)}/day exceeds safe ₹${(safeDailySpendPaise / 100).toFixed(0)}/day.`;
  } else if (dailyVelocityPaise > safeDailySpendPaise && safeDailySpendPaise > 0) {
    status = 'WARNING';
    message = `Caution: spending pace slightly higher than safe daily allowance.`;
  } else if (currentBalancePaise <= 0) {
    status = 'DEPLETED';
    message = 'Funds depleted! Overdraft risk active.';
  }

  return {
    daysRemaining,
    totalDaysInMonth,
    currentDay,
    totalSpentLast7DaysPaise,
    dailyVelocityPaise,
    projectedBalancePaise,
    runwayDays,
    safeDailySpendPaise,
    status,
    message
  };
}

module.exports = {
  calculateBurnRate
};
