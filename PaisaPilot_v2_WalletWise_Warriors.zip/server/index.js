/**
 * PaisaPilot Express Application Entry Point
 * 3-Tier Academic Final Year Project Architecture
 */

const express = require('express');
const cors = require('cors');
const path = require('node:path');
const { getDatabase } = require('./db/database');
const { generate60DayData } = require('./db/seed');

const transactionsRouter = require('./routes/transactions');
const budgetsRouter = require('./routes/budgets');
const profileRouter = require('./routes/profile');
const analyticsRouter = require('./routes/analytics');
const syncRouter = require('./routes/sync');
const badgesRouter = require('./routes/badges');

const app = express();
const PORT = process.env.PORT || 3000;

// Security & Parsing Middleware
app.use(cors());
app.use(express.json({ limit: '5mb' }));
app.use(express.urlencoded({ extended: true }));

// Initialize database schema on startup
getDatabase();

// Mount API Endpoints
app.use('/api/transactions', transactionsRouter);
app.use('/api/budgets', budgetsRouter);
app.use('/api/profile', profileRouter);
app.use('/api/analytics', analyticsRouter);
app.use('/api/sync', syncRouter);
app.use('/api/badges', badgesRouter);

// Demo / Judge evaluation helper: Reset and Seed 60-day dataset
app.post('/api/demo/seed', (req, res) => {
  try {
    const count = generate60DayData();
    res.json({
      success: true,
      message: `Reset database and seeded ${count} student transactions for the 60-day archetype.`
    });
  } catch (err) {
    console.error('Seed error:', err);
    res.status(500).json({ success: false, error: 'Failed to seed sample data' });
  }
});

// Serve Frontend Static Assets
app.use(express.static(path.join(__dirname, '..', 'public')));

// Root route fallback to public/index.html
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'public', 'index.html'));
});

// 404 Handler for unmatched API routes
app.use('/api', (req, res) => {
  res.status(404).json({ success: false, error: 'Endpoint not found' });
});

// Centralized Error Handling Middleware
app.use((err, req, res, next) => {
  console.error('Unhandled server error:', err);
  res.status(500).json({
    success: false,
    error: 'Internal server error',
    message: process.env.NODE_ENV === 'production' ? 'An unexpected error occurred' : err.message
  });
});

if (require.main === module) {
  app.listen(PORT, () => {
    console.log(`=======================================================`);
    console.log(`🚀 PaisaPilot Server Running on http://localhost:${PORT}`);
    console.log(`📁 3-Tier Architecture: Express + SQLite + Responsive UI`);
    console.log(`=======================================================`);
  });
}

module.exports = app;
