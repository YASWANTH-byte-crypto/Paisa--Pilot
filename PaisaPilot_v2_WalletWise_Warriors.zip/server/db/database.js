/**
 * SQLite Database Connection & Initialization
 * Uses Node.js v22+ native node:sqlite DatabaseSync for zero native build dependencies
 * and high-performance transactional persistence.
 */

const { DatabaseSync } = require('node:sqlite');
const path = require('node:path');
const fs = require('node:fs');

const DB_PATH = path.join(__dirname, '..', '..', 'paisapilot.sqlite');

let dbInstance = null;

function getDatabase(customPath = DB_PATH) {
  if (dbInstance && customPath === DB_PATH) {
    return dbInstance;
  }

  const db = new DatabaseSync(customPath);
  
  // Pragmas for performance and relational integrity
  db.exec('PRAGMA foreign_keys = ON;');
  db.exec('PRAGMA journal_mode = WAL;');

  // Initialize schema
  const schemaPath = path.join(__dirname, 'schema.sql');
  const schemaSql = fs.readFileSync(schemaPath, 'utf8');
  db.exec(schemaSql);

  // Initialize default profile if missing
  const profileCount = db.prepare('SELECT COUNT(*) as count FROM profiles').get().count;
  if (profileCount === 0) {
    db.prepare(`
      INSERT INTO profiles (id, name, college, monthly_allowance_paise, currency)
      VALUES (1, 'Arjun Sharma', 'MRV College of Engineering', 500000, 'INR')
    `).run();
  }

  // Initialize standard categories if missing
  const categoryCount = db.prepare('SELECT COUNT(*) as count FROM categories').get().count;
  if (categoryCount === 0) {
    const defaultCategories = [
      ['food', 'Food & Dining', '🍔', '#168c88', 150000],          // ₹1,500 budget cap
      ['books', 'Books & Stationery', '📚', '#49b8d0', 100000],     // ₹1,000 budget cap
      ['rent', 'Hostel / Rent', '🏠', '#f3b45e', 200000],           // ₹2,000 budget cap
      ['entertainment', 'Entertainment', '🎬', '#e87991', 80000],  // ₹800 budget cap
      ['utilities', 'Bills & Utilities', '⚡', '#7d83db', 50000],    // ₹500 budget cap
      ['transport', 'Transport & Metro', '🚇', '#65b98d', 60000],   // ₹600 budget cap
      ['other', 'Personal / Other', '🛍️', '#aab7c4', 40000]         // ₹400 budget cap
    ];

    const insertCategory = db.prepare(`
      INSERT INTO categories (id, name, icon, color, monthly_budget_paise)
      VALUES (?, ?, ?, ?, ?)
    `);

    for (const cat of defaultCategories) {
      insertCategory.run(...cat);
    }
  }

  // Initialize badges if missing
  const badgeCount = db.prepare('SELECT COUNT(*) as count FROM savings_badges').get().count;
  if (badgeCount === 0) {
    const defaultBadges = [
      ['badge-thrifty', 'thrifty_scholar', 'Thrifty Scholar', 'Keep weekly spending below 25% of allowance', '🎓'],
      ['badge-ninja', 'budget_ninja', 'Budget Ninja', 'Zero category threshold breaches this month', '🥷'],
      ['badge-mess', 'mess_master', 'Mess Master', 'Logged 5+ student mess / canteen meals', '🍲'],
      ['badge-rainy', 'rainy_day_hero', 'Rainy Day Hero', 'Maintained positive cash reserve at month-end', '🛡️'],
      ['badge-audit', 'audit_champion', 'Audit Champion', 'Exported financial audit report to CSV', '📊'],
      ['badge-splitter', 'bill_splitter', 'Canteen Splitter', 'Generated shared UPI payment split links', '🤝']
    ];

    const insertBadge = db.prepare(`
      INSERT INTO savings_badges (id, badge_key, title, description, icon, unlocked)
      VALUES (?, ?, ?, ?, ?, 0)
    `);

    for (const b of defaultBadges) {
      insertBadge.run(...b);
    }
  }

  if (customPath === DB_PATH) {
    dbInstance = db;
  }
  return db;
}

module.exports = {
  getDatabase,
  DB_PATH
};
