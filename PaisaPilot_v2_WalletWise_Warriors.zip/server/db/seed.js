/**
 * PaisaPilot 60-Day Student Archetype Seed Dataset
 * Accurately models a typical engineering student over 2 complete calendar months:
 * - Monthly ₹5,000 allowance & freelance/stipend credits
 * - Daily mess food, chai stall UPI micro-payments, canteen bills
 * - Monthly semester books, xerox copies, metro recharges, hostel Wi-Fi bills
 */

const { getDatabase } = require('./database');
const { toPaise } = require('../utils/currency');
const crypto = require('node:crypto');

function generate60DayData(db = getDatabase()) {
  // Clear existing transactions to provide a clean seed
  db.exec('DELETE FROM transactions;');
  db.exec('DELETE FROM budget_alerts;');

  const insertStmt = db.prepare(`
    INSERT INTO transactions (id, merchant, amount_paise, type, category_id, payment_method, date, notes)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `);

  const now = new Date();
  const transactions = [];

  // Helper to get date string offset by days from today
  function getDateOffset(daysAgo) {
    const d = new Date(now);
    d.setDate(d.getDate() - daysAgo);
    return d.toISOString().split('T')[0];
  }

  // --- Month 1 (45 to 60 days ago) ---
  // Stipend / Allowance credits
  transactions.push({ merchant: 'Monthly Family Allowance', amount: 5000, type: 'Income', category: 'other', payment: 'Bank Transfer', daysAgo: 59, notes: 'Semester month 1 allowance' });
  transactions.push({ merchant: 'Coding Tutoring Part-time', amount: 2000, type: 'Income', category: 'other', payment: 'UPI', daysAgo: 45, notes: 'Peer tutoring stipend' });

  // Recurring & student lifestyle expenses
  transactions.push({ merchant: 'College Mess Monthly Fee', amount: 2200, type: 'Expense', category: 'food', payment: 'UPI', daysAgo: 58, notes: 'Monthly dinner subscription' });
  transactions.push({ merchant: 'Engineering Mathematics Textbook', amount: 850, type: 'Expense', category: 'books', payment: 'Card', daysAgo: 55, notes: 'Reference text' });
  transactions.push({ merchant: 'College Canteen Lunch', amount: 120, type: 'Expense', category: 'food', payment: 'UPI', daysAgo: 53, notes: 'Thali' });
  transactions.push({ merchant: 'Campus Chai & Samosa Stall', amount: 45, type: 'Expense', category: 'food', payment: 'UPI', daysAgo: 51, notes: 'Evening snacks' });
  transactions.push({ merchant: 'Delhi Metro Smart Card Recharge', amount: 500, type: 'Expense', category: 'transport', payment: 'UPI', daysAgo: 50, notes: 'Monthly transit' });
  transactions.push({ merchant: 'Hostel High-speed Wi-Fi', amount: 400, type: 'Expense', category: 'utilities', payment: 'UPI', daysAgo: 48, notes: 'Monthly internet' });
  transactions.push({ merchant: 'Lab Manual & Xerox Copies', amount: 180, type: 'Expense', category: 'books', payment: 'Cash', daysAgo: 46, notes: 'Circuit theory printouts' });
  transactions.push({ merchant: 'Hostel Laundry Services', amount: 250, type: 'Expense', category: 'utilities', payment: 'Cash', daysAgo: 42, notes: 'Bedding wash' });
  transactions.push({ merchant: 'Campus Cinema Night', amount: 250, type: 'Expense', category: 'entertainment', payment: 'UPI', daysAgo: 38, notes: 'Weekend movie ticket' });
  transactions.push({ merchant: 'Late Night Maggi Point', amount: 70, type: 'Expense', category: 'food', payment: 'UPI', daysAgo: 35, notes: 'Exam prep midnight snack' });

  // --- Month 2 (Recent 30 days) ---
  // Month 2 Allowance
  transactions.push({ merchant: 'Monthly Family Allowance', amount: 5000, type: 'Income', category: 'other', payment: 'Bank Transfer', daysAgo: 29, notes: 'Semester month 2 allowance' });
  transactions.push({ merchant: 'Freelance Frontend Gig', amount: 1500, type: 'Income', category: 'other', payment: 'UPI', daysAgo: 20, notes: 'Portfolio bug fixes' });

  transactions.push({ merchant: 'College Mess Monthly Fee', amount: 2200, type: 'Expense', category: 'food', payment: 'UPI', daysAgo: 28, notes: 'Month 2 mess fee' });
  transactions.push({ merchant: 'Data Structures Algorithm Guide', amount: 650, type: 'Expense', category: 'books', payment: 'Card', daysAgo: 25, notes: 'Cormen book copy' });
  transactions.push({ merchant: 'Campus Stationery & Record Files', amount: 220, type: 'Expense', category: 'books', payment: 'Cash', daysAgo: 22, notes: 'Practical record sheets' });
  transactions.push({ merchant: 'Hostel Electricity Share', amount: 350, type: 'Expense', category: 'utilities', payment: 'UPI', daysAgo: 18, notes: 'Room cooler charge' });
  transactions.push({ merchant: 'Metro Travel Recharge', amount: 400, type: 'Expense', category: 'transport', payment: 'UPI', daysAgo: 15, notes: 'Metro balance' });
  transactions.push({ merchant: 'Canteen Dosa & Filter Coffee', amount: 110, type: 'Expense', category: 'food', payment: 'UPI', daysAgo: 12, notes: 'Breakfast' });
  transactions.push({ merchant: 'Streaming Music Subscription', amount: 119, type: 'Expense', category: 'entertainment', payment: 'UPI', daysAgo: 10, notes: 'Student discount tier' });

  // --- Last 7 Days (for burn rate velocity & demo calculations) ---
  transactions.push({ merchant: 'Campus Tea Stall', amount: 40, type: 'Expense', category: 'food', payment: 'UPI', daysAgo: 6, notes: 'Chai with study group' });
  transactions.push({ merchant: 'College Canteen Lunch', amount: 140, type: 'Expense', category: 'food', payment: 'UPI', daysAgo: 5, notes: 'Special thali' });
  transactions.push({ merchant: 'Campus Stationery Pens & Notebooks', amount: 95, type: 'Expense', category: 'books', payment: 'Cash', daysAgo: 4, notes: 'Exam revision pens' });
  transactions.push({ merchant: 'Auto Rickshaw to Exam Hall', amount: 60, type: 'Expense', category: 'transport', payment: 'Cash', daysAgo: 3, notes: 'Shared ride' });
  transactions.push({ merchant: 'Campus Juice Corner', amount: 50, type: 'Expense', category: 'food', payment: 'UPI', daysAgo: 2, notes: 'Fresh fruit juice' });
  transactions.push({ merchant: 'Late Night Nescafe Stall', amount: 35, type: 'Expense', category: 'food', payment: 'UPI', daysAgo: 1, notes: 'Coffee' });
  transactions.push({ merchant: 'Mess Snacks & Patties', amount: 60, type: 'Expense', category: 'food', payment: 'UPI', daysAgo: 0, notes: 'Evening snack' });

  // Execute inserts inside a transaction
  db.exec('BEGIN TRANSACTION;');
  try {
    for (const t of transactions) {
      const id = 'tx-' + crypto.randomUUID().slice(0, 8);
      const dateStr = getDateOffset(t.daysAgo);
      insertStmt.run(
        id,
        t.merchant,
        toPaise(t.amount),
        t.type,
        t.category,
        t.payment,
        dateStr,
        t.notes || ''
      );
    }
    db.exec('COMMIT;');
  } catch (err) {
    db.exec('ROLLBACK;');
    throw err;
  }

  console.log(`Successfully seeded ${transactions.length} realistic student transactions over 60 days!`);
  return transactions.length;
}

if (require.main === module) {
  generate60DayData();
}

module.exports = {
  generate60DayData
};
