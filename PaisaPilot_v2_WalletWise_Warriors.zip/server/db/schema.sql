-- PaisaPilot Relational Schema (SQLite)
-- Final Year Engineering Standard 3-Tier Architecture

PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS profiles (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    name TEXT NOT NULL DEFAULT 'Arjun Sharma',
    college TEXT NOT NULL DEFAULT 'MRV College of Engineering',
    monthly_allowance_paise INTEGER NOT NULL DEFAULT 500000, -- ₹5,000.00
    currency TEXT NOT NULL DEFAULT 'INR',
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS categories (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    icon TEXT NOT NULL,
    color TEXT NOT NULL,
    monthly_budget_paise INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS transactions (
    id TEXT PRIMARY KEY,
    merchant TEXT NOT NULL,
    amount_paise INTEGER NOT NULL,
    type TEXT NOT NULL CHECK(type IN ('Income', 'Expense')),
    category_id TEXT NOT NULL REFERENCES categories(id) ON UPDATE CASCADE,
    payment_method TEXT NOT NULL CHECK(payment_method IN ('UPI', 'Cash', 'Card', 'Bank Transfer', 'Other')),
    date TEXT NOT NULL,
    notes TEXT DEFAULT '',
    sync_version INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_transactions_date ON transactions(date);
CREATE INDEX IF NOT EXISTS idx_transactions_category ON transactions(category_id);
CREATE INDEX IF NOT EXISTS idx_transactions_type ON transactions(type);

CREATE TABLE IF NOT EXISTS budget_alerts (
    id TEXT PRIMARY KEY,
    category_id TEXT NOT NULL REFERENCES categories(id),
    threshold INTEGER NOT NULL CHECK (threshold IN (80, 100)),
    spent_paise INTEGER NOT NULL,
    budget_paise INTEGER NOT NULL,
    month TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS savings_badges (
    id TEXT PRIMARY KEY,
    badge_key TEXT NOT NULL UNIQUE,
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    icon TEXT NOT NULL,
    unlocked INTEGER NOT NULL DEFAULT 0,
    unlocked_at TEXT
);
