/**
 * Category Budgets & Threshold Monitor API
 * Configurable category-wise budget caps with 80% & 100% threshold monitoring (SRS 3.3)
 */

const express = require('express');
const router = express.Router();
const { getDatabase } = require('../db/database');
const { validateBudget } = require('../utils/validation');

// GET /api/budgets - List all categories with budget caps and current month spending
router.get('/', (req, res) => {
  try {
    const db = getDatabase();
    const currentMonth = (req.query.month || new Date().toISOString().slice(0, 7)); // 'YYYY-MM'

    const categories = db.prepare('SELECT * FROM categories ORDER BY id').all();

    const spendingReport = categories.map(cat => {
      const spentRow = db.prepare(`
        SELECT COALESCE(SUM(amount_paise), 0) as spent_paise
        FROM transactions
        WHERE category_id = ? AND type = 'Expense' AND date LIKE ?
      `).get(cat.id, `${currentMonth}%`);

      const spentPaise = spentRow.spent_paise || 0;
      const budgetPaise = cat.monthly_budget_paise || 0;
      const percentage = budgetPaise > 0 ? Math.round((spentPaise / budgetPaise) * 100) : 0;

      let status = 'HEALTHY';
      if (percentage >= 100) {
        status = 'BREACHED'; // 100% cap exceeded
      } else if (percentage >= 80) {
        status = 'WARNING'; // 80% alert threshold
      }

      return {
        id: cat.id,
        name: cat.name,
        icon: cat.icon,
        color: cat.color,
        monthly_budget_paise: budgetPaise,
        monthly_budget_rupees: budgetPaise / 100,
        spent_paise: spentPaise,
        spent_rupees: spentPaise / 100,
        remaining_paise: Math.max(0, budgetPaise - spentPaise),
        remaining_rupees: Math.max(0, (budgetPaise - spentPaise) / 100),
        percentage,
        status
      };
    });

    res.json({
      success: true,
      month: currentMonth,
      data: spendingReport
    });
  } catch (err) {
    console.error('Error fetching budgets:', err);
    res.status(500).json({ success: false, error: 'Database error' });
  }
});

// PUT /api/budgets/:categoryId - Set category budget cap
router.put('/:categoryId', (req, res) => {
  try {
    const categoryId = req.params.categoryId.toLowerCase();
    const validation = validateBudget({ ...req.body, category_id: categoryId });
    if (!validation.isValid) {
      return res.status(400).json({ success: false, errors: validation.errors });
    }

    const db = getDatabase();
    const { monthly_budget_paise } = validation.data;

    const result = db.prepare(`
      UPDATE categories
      SET monthly_budget_paise = ?
      WHERE id = ?
    `).run(monthly_budget_paise, categoryId);

    if (result.changes === 0) {
      return res.status(404).json({ success: false, error: 'Category not found' });
    }

    const updated = db.prepare('SELECT * FROM categories WHERE id = ?').get(categoryId);
    res.json({
      success: true,
      message: `Budget cap for ${updated.name} updated to ₹${(monthly_budget_paise / 100).toFixed(2)}`,
      data: updated
    });
  } catch (err) {
    console.error('Error updating budget:', err);
    res.status(500).json({ success: false, error: 'Database error' });
  }
});

module.exports = router;
