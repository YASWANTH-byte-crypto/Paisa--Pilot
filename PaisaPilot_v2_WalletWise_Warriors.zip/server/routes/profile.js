/**
 * Student Profile & Monthly Allowance API
 */

const express = require('express');
const router = express.Router();
const { getDatabase } = require('../db/database');
const { toPaise } = require('../utils/currency');

// GET /api/profile
router.get('/', (req, res) => {
  try {
    const db = getDatabase();
    const profile = db.prepare('SELECT * FROM profiles WHERE id = 1').get();
    res.json({
      success: true,
      data: {
        ...profile,
        monthly_allowance_rupees: (profile.monthly_allowance_paise || 0) / 100
      }
    });
  } catch (err) {
    console.error('Error fetching profile:', err);
    res.status(500).json({ success: false, error: 'Failed to fetch profile' });
  }
});

// PUT /api/profile
router.put('/', (req, res) => {
  try {
    const { monthly_allowance, name, college } = req.body;
    const db = getDatabase();

    const current = db.prepare('SELECT * FROM profiles WHERE id = 1').get();
    const newAllowancePaise = monthly_allowance !== undefined ? toPaise(monthly_allowance) : current.monthly_allowance_paise;
    const newName = name || current.name;
    const newCollege = college || current.college;

    db.prepare(`
      UPDATE profiles
      SET monthly_allowance_paise = ?, name = ?, college = ?, updated_at = datetime('now')
      WHERE id = 1
    `).run(newAllowancePaise, newName, newCollege);

    const updated = db.prepare('SELECT * FROM profiles WHERE id = 1').get();
    res.json({
      success: true,
      message: 'Profile updated successfully',
      data: {
        ...updated,
        monthly_allowance_rupees: updated.monthly_allowance_paise / 100
      }
    });
  } catch (err) {
    console.error('Error updating profile:', err);
    res.status(500).json({ success: false, error: 'Failed to update profile' });
  }
});

module.exports = router;
