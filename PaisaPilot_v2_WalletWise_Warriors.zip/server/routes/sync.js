/**
 * Offline Synchronization API (IndexedDB to SQLite)
 * Handles optimistic offline mutation queuing, conflict resolution,
 * and bulk batch synchronization.
 */

const express = require('express');
const router = express.Router();
const { getDatabase } = require('../db/database');

// POST /api/sync - Batch synchronizes offline transactions
router.post('/', (req, res) => {
  try {
    const { created = [], updated = [], deleted = [] } = req.body;
    const db = getDatabase();

    db.exec('BEGIN TRANSACTION;');

    try {
      // 1. Process deletions
      if (deleted.length > 0) {
        const deleteStmt = db.prepare('DELETE FROM transactions WHERE id = ?');
        for (const id of deleted) {
          deleteStmt.run(id);
        }
      }

      // 2. Process insertions & updates
      const upsertStmt = db.prepare(`
        INSERT INTO transactions (id, merchant, amount_paise, type, category_id, payment_method, date, notes, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
        ON CONFLICT(id) DO UPDATE SET
          merchant = excluded.merchant,
          amount_paise = excluded.amount_paise,
          type = excluded.type,
          category_id = excluded.category_id,
          payment_method = excluded.payment_method,
          date = excluded.date,
          notes = excluded.notes,
          updated_at = datetime('now')
      `);

      for (const t of [...created, ...updated]) {
        upsertStmt.run(
          t.id,
          t.merchant,
          t.amount_paise || Math.round(Number(t.amount) * 100),
          t.type,
          (t.category_id || t.category || 'other').toLowerCase(),
          t.payment_method || t.payment || 'UPI',
          t.date,
          t.notes || ''
        );
      }

      db.exec('COMMIT;');
    } catch (txErr) {
      db.exec('ROLLBACK;');
      throw txErr;
    }

    // Return the latest complete dataset from server
    const fullTransactions = db.prepare(`
      SELECT t.*, c.name as category_name, c.icon as category_icon, c.color as category_color
      FROM transactions t
      JOIN categories c ON t.category_id = c.id
      ORDER BY t.date DESC, t.created_at DESC
    `).all();

    res.json({
      success: true,
      message: `Synchronized ${created.length} new, ${updated.length} updated, and ${deleted.length} deleted transactions.`,
      serverTransactions: fullTransactions,
      syncTimestamp: new Date().toISOString()
    });
  } catch (err) {
    console.error('Sync failure:', err);
    res.status(500).json({ success: false, error: 'Synchronization failed' });
  }
});

module.exports = router;
