/**
 * Gamified Savings Badges & Milestones API
 */

const express = require('express');
const router = express.Router();
const { getDatabase } = require('../db/database');

router.get('/', (req, res) => {
  try {
    const db = getDatabase();

    // Check conditions dynamically to unlock badges
    const totalTransactions = db.prepare('SELECT COUNT(*) as count FROM transactions').get().count;
    const messMealsCount = db.prepare(`
      SELECT COUNT(*) as count FROM transactions 
      WHERE (category_id = 'food' OR merchant LIKE '%mess%' OR merchant LIKE '%canteen%') AND type = 'Expense'
    `).get().count;

    const profile = db.prepare('SELECT monthly_allowance_paise FROM profiles WHERE id = 1').get();
    const allowance = profile ? profile.monthly_allowance_paise : 500000;

    const income = db.prepare(`SELECT COALESCE(SUM(amount_paise), 0) as sum FROM transactions WHERE type = 'Income'`).get().sum;
    const expense = db.prepare(`SELECT COALESCE(SUM(amount_paise), 0) as sum FROM transactions WHERE type = 'Expense'`).get().sum;
    const balance = allowance + income - expense;

    // Check if any budget was breached this month
    const currentMonth = new Date().toISOString().slice(0, 7);
    const categories = db.prepare('SELECT * FROM categories').all();
    let hasBreach = false;
    for (const cat of categories) {
      if (cat.monthly_budget_paise > 0) {
        const spent = db.prepare(`
          SELECT COALESCE(SUM(amount_paise), 0) as sum FROM transactions
          WHERE category_id = ? AND type = 'Expense' AND date LIKE ?
        `).get(cat.id, `${currentMonth}%`).sum;
        if (spent > cat.monthly_budget_paise) {
          hasBreach = true;
          break;
        }
      }
    }

    // Auto unlock rules
    const unlockStmt = db.prepare(`
      UPDATE savings_badges SET unlocked = 1, unlocked_at = datetime('now') WHERE badge_key = ? AND unlocked = 0
    `);

    if (totalTransactions >= 10 && !hasBreach) {
      unlockStmt.run('budget_ninja');
    }
    if (messMealsCount >= 5) {
      unlockStmt.run('mess_master');
    }
    if (balance > (allowance * 0.2)) {
      unlockStmt.run('rainy_day_hero');
    }
    if (totalTransactions >= 5) {
      unlockStmt.run('thrifty_scholar');
    }

    const badges = db.prepare('SELECT * FROM savings_badges ORDER BY id').all();
    res.json({
      success: true,
      badges
    });
  } catch (err) {
    console.error('Error fetching badges:', err);
    res.status(500).json({ success: false, error: 'Failed to fetch badges' });
  }
});

module.exports = router;
