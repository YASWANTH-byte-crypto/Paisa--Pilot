/**
 * Transactions API Routes
 * Endpoints for CRUD, instant multi-filtering, sorting, and pagination
 */

const express = require('express');
const router = express.Router();
const crypto = require('node:crypto');
const { getDatabase } = require('../db/database');
const { validateTransaction } = require('../utils/validation');
const { toPaise } = require('../utils/currency');

// GET /api/transactions - Query with multi-filter & pagination
router.get('/', (req, res) => {
  try {
    const db = getDatabase();
    const {
      search = '',
      category = '',
      type = '',
      startDate = '',
      endDate = '',
      sort = 'date',
      order = 'DESC',
      limit = 100,
      offset = 0
    } = req.query;

    let query = `
      SELECT t.*, c.name as category_name, c.icon as category_icon, c.color as category_color
      FROM transactions t
      JOIN categories c ON t.category_id = c.id
      WHERE 1=1
    `;
    const params = [];

    if (search.trim()) {
      query += ` AND t.merchant LIKE ?`;
      params.push(`%${search.trim()}%`);
    }

    if (category && category !== 'All') {
      query += ` AND t.category_id = ?`;
      params.push(category.toLowerCase());
    }

    if (type && type !== 'All') {
      query += ` AND t.type = ?`;
      params.push(type);
    }

    if (startDate) {
      query += ` AND t.date >= ?`;
      params.push(startDate);
    }

    if (endDate) {
      query += ` AND t.date <= ?`;
      params.push(endDate);
    }

    // Safe sorting
    const validSortCols = ['date', 'amount_paise', 'merchant', 'created_at'];
    const sortCol = validSortCols.includes(sort) ? sort : 'date';
    const sortDir = order.toUpperCase() === 'ASC' ? 'ASC' : 'DESC';

    query += ` ORDER BY t.${sortCol} ${sortDir}, t.created_at DESC`;
    query += ` LIMIT ? OFFSET ?`;
    params.push(Number(limit) || 100, Number(offset) || 0);

    const transactions = db.prepare(query).all(...params);

    // Get count for pagination
    let countQuery = `SELECT COUNT(*) as total FROM transactions t WHERE 1=1`;
    const countParams = [];
    if (search.trim()) {
      countQuery += ` AND t.merchant LIKE ?`;
      countParams.push(`%${search.trim()}%`);
    }
    if (category && category !== 'All') {
      countQuery += ` AND t.category_id = ?`;
      countParams.push(category.toLowerCase());
    }
    if (type && type !== 'All') {
      countQuery += ` AND t.type = ?`;
      countParams.push(type);
    }
    if (startDate) {
      countQuery += ` AND t.date >= ?`;
      countParams.push(startDate);
    }
    if (endDate) {
      countQuery += ` AND t.date <= ?`;
      countParams.push(endDate);
    }

    const totalCount = db.prepare(countQuery).get(...countParams).total;

    res.json({
      success: true,
      total: totalCount,
      count: transactions.length,
      data: transactions
    });
  } catch (err) {
    console.error('Error fetching transactions:', err);
    res.status(500).json({ success: false, error: 'Database query failed' });
  }
});

// POST /api/transactions - Create new transaction with automated budget threshold monitoring
router.post('/', (req, res) => {
  try {
    const validation = validateTransaction(req.body);
    if (!validation.isValid) {
      return res.status(400).json({ success: false, errors: validation.errors });
    }

    const db = getDatabase();
    const { merchant, amount, type, category_id, payment_method, date, notes } = validation.data;
    const amount_paise = toPaise(amount);
    const id = req.body.id || ('tx-' + crypto.randomUUID().slice(0, 8));

    const insertStmt = db.prepare(`
      INSERT INTO transactions (id, merchant, amount_paise, type, category_id, payment_method, date, notes, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
    `);

    insertStmt.run(id, merchant, amount_paise, type, category_id, payment_method, date, notes);

    // Retrieve created record
    const created = db.prepare(`
      SELECT t.*, c.name as category_name, c.icon as category_icon, c.color as category_color
      FROM transactions t
      JOIN categories c ON t.category_id = c.id
      WHERE t.id = ?
    `).get(id);

    // Automated Budget Threshold Monitor Check
    let budgetAlert = null;
    if (type === 'Expense') {
      const monthPrefix = date.slice(0, 7); // 'YYYY-MM'
      const catInfo = db.prepare(`
        SELECT monthly_budget_paise, name FROM categories WHERE id = ?
      `).get(category_id);

      if (catInfo && catInfo.monthly_budget_paise > 0) {
        const spentObj = db.prepare(`
          SELECT SUM(amount_paise) as total_spent
          FROM transactions
          WHERE category_id = ? AND type = 'Expense' AND date LIKE ?
        `).get(category_id, `${monthPrefix}%`);

        const totalSpent = spentObj.total_spent || 0;
        const budget = catInfo.monthly_budget_paise;
        const percentage = Math.round((totalSpent / budget) * 100);

        if (percentage >= 100) {
          budgetAlert = {
            category: catInfo.name,
            threshold: 100,
            percentage,
            spentRupees: totalSpent / 100,
            budgetRupees: budget / 100,
            message: `⚠️ CRITICAL: You have EXCEEDED 100% of your ${catInfo.name} budget (₹${(totalSpent/100).toFixed(2)} / ₹${(budget/100).toFixed(2)})!`
          };
        } else if (percentage >= 80) {
          budgetAlert = {
            category: catInfo.name,
            threshold: 80,
            percentage,
            spentRupees: totalSpent / 100,
            budgetRupees: budget / 100,
            message: `🔔 WARNING: You have reached ${percentage}% of your ${catInfo.name} monthly budget cap!`
          };
        }
      }
    }

    res.status(201).json({
      success: true,
      data: created,
      budgetAlert
    });
  } catch (err) {
    console.error('Error inserting transaction:', err);
    res.status(500).json({ success: false, error: 'Failed to record transaction' });
  }
});

// DELETE /api/transactions/:id - Delete transaction
router.delete('/:id', (req, res) => {
  try {
    const db = getDatabase();
    const result = db.prepare('DELETE FROM transactions WHERE id = ?').run(req.params.id);
    if (result.changes === 0) {
      return res.status(404).json({ success: false, error: 'Transaction not found' });
    }
    res.json({ success: true, message: 'Transaction successfully deleted' });
  } catch (err) {
    console.error('Error deleting transaction:', err);
    res.status(500).json({ success: false, error: 'Failed to delete transaction' });
  }
});

module.exports = router;
