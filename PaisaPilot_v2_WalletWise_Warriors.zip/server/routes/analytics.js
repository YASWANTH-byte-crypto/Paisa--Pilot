/**
 * Analytics & Burn Rate Heuristics API
 * Calculates live balance, category distribution, 7-day burn rate velocity,
 * and daily safe-spend allowance.
 */

const express = require('express');
const router = express.Router();
const { getDatabase } = require('../db/database');
const { calculateBurnRate } = require('../utils/burnRate');

// GET /api/analytics
router.get('/', (req, res) => {
  try {
    const db = getDatabase();
    const profile = db.prepare('SELECT monthly_allowance_paise FROM profiles WHERE id = 1').get();
    const allowancePaise = profile ? profile.monthly_allowance_paise : 500000;

    // Totals across all transactions
    const incomeRow = db.prepare(`SELECT COALESCE(SUM(amount_paise), 0) as total FROM transactions WHERE type = 'Income'`).get();
    const expenseRow = db.prepare(`SELECT COALESCE(SUM(amount_paise), 0) as total FROM transactions WHERE type = 'Expense'`).get();

    const totalIncomePaise = incomeRow.total || 0;
    const totalExpensesPaise = expenseRow.total || 0;
    const availableBalancePaise = allowancePaise + totalIncomePaise - totalExpensesPaise;

    // Category breakdown
    const categories = db.prepare('SELECT * FROM categories ORDER BY id').all();
    const categoryBreakdown = categories.map(cat => {
      const row = db.prepare(`
        SELECT COALESCE(SUM(amount_paise), 0) as total
        FROM transactions
        WHERE category_id = ? AND type = 'Expense'
      `).get(cat.id);

      return {
        id: cat.id,
        name: cat.name,
        icon: cat.icon,
        color: cat.color,
        spent_paise: row.total,
        spent_rupees: row.total / 100
      };
    });

    // All transactions for burn rate heuristics
    const allExpenses = db.prepare(`
      SELECT amount_paise, type, date FROM transactions WHERE type = 'Expense' ORDER BY date DESC
    `).all();

    const burnRateAnalysis = calculateBurnRate(allExpenses, availableBalancePaise);

    // Monthly cash flow timeline (past 6 months)
    const monthlyHistory = db.prepare(`
      SELECT 
        substr(date, 1, 7) as month,
        SUM(CASE WHEN type = 'Income' THEN amount_paise ELSE 0 END) as income_paise,
        SUM(CASE WHEN type = 'Expense' THEN amount_paise ELSE 0 END) as expense_paise
      FROM transactions
      GROUP BY substr(date, 1, 7)
      ORDER BY month ASC
      LIMIT 6
    `).all();

    res.json({
      success: true,
      summary: {
        monthly_allowance_rupees: allowancePaise / 100,
        monthly_allowance_paise: allowancePaise,
        total_income_rupees: totalIncomePaise / 100,
        total_income_paise: totalIncomePaise,
        total_expenses_rupees: totalExpensesPaise / 100,
        total_expenses_paise: totalExpensesPaise,
        available_balance_rupees: availableBalancePaise / 100,
        available_balance_paise: availableBalancePaise,
        safe_daily_spend_rupees: burnRateAnalysis.safeDailySpendPaise / 100,
        safe_daily_spend_paise: burnRateAnalysis.safeDailySpendPaise
      },
      burnRate: {
        daily_velocity_rupees: burnRateAnalysis.dailyVelocityPaise / 100,
        daily_velocity_paise: burnRateAnalysis.dailyVelocityPaise,
        total_spent_last_7_days_rupees: burnRateAnalysis.totalSpentLast7DaysPaise / 100,
        days_remaining_in_month: burnRateAnalysis.daysRemaining,
        projected_balance_rupees: burnRateAnalysis.projectedBalancePaise / 100,
        projected_balance_paise: burnRateAnalysis.projectedBalancePaise,
        runway_days: burnRateAnalysis.runwayDays,
        status: burnRateAnalysis.status,
        message: burnRateAnalysis.message
      },
      categories: categoryBreakdown,
      monthlyHistory: monthlyHistory.map(m => ({
        month: m.month,
        income_rupees: (m.income_paise || 0) / 100,
        expense_rupees: (m.expense_paise || 0) / 100,
        net_rupees: ((m.income_paise || 0) - (m.expense_paise || 0)) / 100
      }))
    });
  } catch (err) {
    console.error('Error generating analytics:', err);
    res.status(500).json({ success: false, error: 'Failed to calculate analytics' });
  }
});

module.exports = router;
